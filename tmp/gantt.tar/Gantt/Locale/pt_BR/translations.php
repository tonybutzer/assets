<?php

return array(
    'Sort by position' => 'Ordenar por posição',
    'Sort by date' => 'Ordenar por data',
    'Add task' => 'Adicionar uma tarefa',
    'There is no start date or due date for this task.' => 'Não existe data de início ou data fim estimada para esta tarefa.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Mover ou redimensionar uma tarefa irá alterar a data de início e conclusão estimada da tarefa.',
    'There is no task in your project.' => 'Não há tarefas em seu projeto.',
    'Gantt chart' => 'Gráfico de Gantt',
    'Gantt chart for all projects' => 'Gráfico de Gantt para todos os projetos',
    'Gantt chart for this project' => 'Gráfico de Gantt para este projeto',
    'Project board' => 'Painel do projeto',
    'There is no start date or end date for this project.' => 'Não há data de início ou data de término para este projeto.',
    'Projects Gantt chart' => 'Gráfico de Gantt dos projetos',
    'Switch to the Gantt chart view' => 'Mudar para a vista gráfico de Gantt',
);

