<?php

return array(
    'Sort by position' => 'Sortiraj po poziciji',
    'Sort by date' => 'Sortiraj po datumu',
    'Add task' => 'Dodaj zadatak',
    'There is no start date or due date for this task.' => 'Nema početnog datuma ili datuma do kada treba završiti ovaj zadatak.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Premještanje ili promjena veličine zadatka će promijeniti datum početka i datum do kada treba završiti zadatak.',
    'There is no task in your project.' => 'Nema zadataka u projektu.',
    'Gantt chart' => 'Gantogram',
    'Gantt chart for all projects' => 'Gantogram za sve projekte',
    'Gantt chart for this project' => 'Gantogram za ovaj projekat',
    'Project board' => 'Ploča projekta',
    'There is no start date or end date for this project.' => 'Nema početnog ili krajnjeg datuma za ovaj projekat.',
    'Projects Gantt chart' => 'Gantogram projekata',
    'Switch to the Gantt chart view' => 'Promijeni u gantogram pregled',
);

