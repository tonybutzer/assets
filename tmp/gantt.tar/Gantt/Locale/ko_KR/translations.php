<?php

return array(
    'Sort by position' => '위치별 정렬',
    'Sort by date' => '날짜별 정렬',
    'Add task' => '할일 추가',
    'There is no start date or due date for this task.' => '할일의 시작일 또는 만기일이 없습니다',
    'Moving or resizing a task will change the start and due date of the task.' => '할일의 이동 혹은 리사이징으로 시작시간과 마감시간이 변경됩니다.',
    'There is no task in your project.' => '프로젝트에 할일이 없습니다.',
    'Gantt chart' => '간트 차트',
    'Gantt chart for all projects' => '모든 프로젝트의 간트 차트',
    'Gantt chart for this project' => '이 프로젝트 간트차트',
    'Project board' => '프로젝트 보드',
    'There is no start date or end date for this project.' => '이 프로젝트에는 시작날짜와 종료날짜가 없습니다',
    'Projects Gantt chart' => '프로젝트 간트차트',
    'Switch to the Gantt chart view' => '간트 차트 보기로 변경',
);

