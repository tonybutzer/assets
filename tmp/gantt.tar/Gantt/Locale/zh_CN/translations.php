<?php

return array(
    'Sort by position' => '按位置排序',
    'Sort by date' => '按日期排序',
    'Add task' => '添加任务',
    'There is no start date or due date for this task.' => '当前任务没有开始或结束时间。',
    'Moving or resizing a task will change the start and due date of the task.' => '移动或者重设任务将改变任务开始和结束时间。',
    'There is no task in your project.' => '当前项目还没有任务',
    'Gantt chart' => '甘特图',
    'Gantt chart for all projects' => '所有项目的甘特图',
    'Gantt chart for this project' => '此项目的甘特图',
    'Project board' => '项目面板',
    'There is no start date or end date for this project.' => '当前项目没有开始或结束日期',
    'Projects Gantt chart' => '项目甘特图',
    'Switch to the Gantt chart view' => '切换到甘特图',
);

