<?php

return array(
    'Sort by position' => 'Ταξινόμηση κατά Θέση',
    'Sort by date' => 'Ταξινόμηση κατά ημέρα',
    'Add task' => 'Προσθήκη εργασίας',
    'There is no start date or due date for this task.' => 'Δεν υπάρχει ημερομηνία έναρξης ή ημερομηνία λήξης καθηκόντων για το έργο αυτό.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Μετακίνηση ή αλλαγή μεγέθους μιας εργασίας θα αλλάξει την ώρα έναρξης και ημερομηνία λήξης της εργασίας.',
    'There is no task in your project.' => 'Δεν υπάρχει καμία εργασία στο έργο σας.',
    'Gantt chart' => 'Διαγράμματα Gantt',
    'Gantt chart for all projects' => 'Διάγραμμα Gantt για όλα τα έργα',
    'Gantt chart for this project' => 'Διάγραμμα Gantt για το έργο',
    'Project board' => 'Κεντρικός πίνακας έργου',
    'There is no start date or end date for this project.' => 'Δεν υπάρχει ημερομηνία έναρξης ή λήξης για το έργο αυτό.',
    'Projects Gantt chart' => 'Διάγραμμα Gantt έργων',
    'Switch to the Gantt chart view' => 'Μεταφορά σε προβολή διαγράμματος Gantt',
);

