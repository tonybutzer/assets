<?php

return array(
    'Sort by position' => '位置でソート',
    'Sort by date' => '日付でソート',
    'Add task' => 'タスクを追加',
    'There is no start date or due date for this task.' => 'このタスクに開始日または期限はありません',
    'Moving or resizing a task will change the start and due date of the task.' => 'バーを移動・サイズ変更すると、タスクの開始日と終了日を変更します',
    'There is no task in your project.' => 'プロジェクトにはタスクがありません',
    'Gantt chart' => 'ガントチャート',
    'Gantt chart for all projects' => 'すべてのプロジェクトのガントチャート',
    'Gantt chart for this project' => 'このプロジェクトのガントチャート',
    'Project board' => 'プロジェクト・ボード',
    'There is no start date or end date for this project.' => 'このプロジェクトに開始日または終了日はありません',
    'Projects Gantt chart' => 'プロジェクト・ガントチャート',
    'Switch to the Gantt chart view' => 'ガントチャート・ビューに切替',
);

