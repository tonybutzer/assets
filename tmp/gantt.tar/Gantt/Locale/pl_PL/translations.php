<?php

return array(
    'Sort by position' => 'Sortuj wg pozycji',
    'Sort by date' => 'Sortuj wg daty',
    'Add task' => 'Dodaj zadanie',
    'There is no start date or due date for this task.' => 'Brak daty rozpoczęcia lub terminu zadania',
    'Moving or resizing a task will change the start and due date of the task.' => 'Przeniesienie bądź edycja zmieni datę rozpoczęcia oraz termin ukończenia zadania.',
    'There is no task in your project.' => 'Brak zadań w projekcie.',
    'Gantt chart' => 'Wykres Gantta',
    'Gantt chart for all projects' => 'Wykres Gantta dla wszystkich projektów',
    'Gantt chart for this project' => 'Wykres Gantta dla bieżacego projektu',
    'Project board' => 'Talica projektu',
    'There is no start date or end date for this project.' => 'Nie zdefiniowano czasu trwania projektu',
    'Projects Gantt chart' => 'Wykres Gantta dla projektów',
    'Switch to the Gantt chart view' => 'Przełącz na wykres Gantta',
);

