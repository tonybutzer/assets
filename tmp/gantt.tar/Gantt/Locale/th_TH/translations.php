<?php

return array(
    'Sort by position' => 'เรียงตามตำแหน่ง',
    'Sort by date' => 'เรียงตามวัน',
    'Add task' => 'เพิ่มงาน',
    'There is no start date or due date for this task.' => 'งานนี้ไม่มีวันที่เริ่มหรือวันครบกำหนด',
    'Moving or resizing a task will change the start and due date of the task.' => 'การย้ายหรือปรับขนาดงานจะมีการเปลี่ยนแปลงที่วันเริ่มต้นและวันที่ครบกำหนดของงาน',
    'There is no task in your project.' => 'โปรเจคนี้ไม่มีงาน',
    'Gantt chart' => 'แผนภูมิแกรนท์',
    'Gantt chart for all projects' => 'แผนภูมิแกรนท์สำหรับทุกโปรเจค',
    'Gantt chart for this project' => 'แผนภูมิแกรนท์สำหรับโปรเจคนี้',
    'Project board' => 'บอร์ดโปรเจค',
    'There is no start date or end date for this project.' => 'ไม่มีวันที่เริ่มหรือวันที่จบของโปรเจคนี้',
    'Projects Gantt chart' => 'แผนภูมิแกรน์ของโปรเจค',
    'Switch to the Gantt chart view' => 'เปลี่ยนเป็นมุมมองแผนภูมิแกรนท์',
);

