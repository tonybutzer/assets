<?php

return array(
    'Sort by position' => 'Sorter udfra position',
    'Sort by date' => 'Sorter ud fra dato',
    'Add task' => 'Tilføj opgave',
    // 'There is no start date or due date for this task.' => '',
    'Moving or resizing a task will change the start and due date of the task.' => 'Hvis du flytter eller trækker i en opgave vil det ændre start -og forfaldsdato',
    'There is no task in your project.' => 'Der er ikke nogle opgaver i dette projekt',
    // 'Gantt chart' => '',
    'Gantt chart for all projects' => 'Gantt chart for alle projekter',
    'Gantt chart for this project' => 'Gantt chart for dette projekt',
    'Project board' => 'Projekt tavle',
    'There is no start date or end date for this project.' => 'Der er ikke nogen start eller slut dato for dette projekt.',
    'Projects Gantt chart' => 'Gantt chart på Projekter',
    // 'Switch to the Gantt chart view' => '',
);

