<?php

return array(
    'Sort by position' => 'Radiť podľa pozície',
    'Sort by date' => 'Radiť podľa dátumu',
    'Sort tasks by position' => 'Radiť úlohy podľa pozície',
    'Sort tasks by date' => 'Radiť úlohy podľa dátumu',
    'Gantt settings' => 'Nastavenia Gantt',
    'Add task' => 'Pridať úlohu',
    'There is no start date or due date for this task.' => 'Táto úloha nemá dátum začiatku alebo termín ukončenia.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Presun alebo zmena veľkosti úlohy zmení počiatočný dátum a termín ukončenia úlohy.',
    'There is no task in your project.' => 'V projekte nie sú žiadne úlohy.',
    'Gantt chart' => 'Ganttov diagram',
    'Gantt chart for all projects' => 'Ganttov diagram všetkých projektov',
    'Gantt chart for this project' => 'Ganttov diagram tohoto projektu',
    'Project board' => 'Nástenka projektu',
    'There is no start date or end date for this project.' => 'Projekt nemá dátum začiatku alebo ukončenia.',
    'Projects Gantt chart' => 'Gantov diagram projektov',
    'Switch to the Gantt chart view' => 'Prepnúť na zobrazenie Ganttovho diagramu',
);
