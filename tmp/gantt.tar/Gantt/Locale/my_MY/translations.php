<?php

return array(
    'Sort by position' => 'Urutkan berdasarkan posisi',
    'Sort by date' => 'Urutkan berdasarkan tanggal',
    'Add task' => 'Tambah tugas',
    'There is no start date or due date for this task.' => 'Tiada tanggal mulai dan batas waktu untuk tugas ini.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Memindahkan atau mengubah ukuran tugas anda akan mengubah tanggal mulai dan batas waktu dari tugas ini.',
    'There is no task in your project.' => 'Tiada tugas didalam projek anda.',
    'Gantt chart' => 'Carta Gantt',
    'Gantt chart for all projects' => 'Carta Gantt untuk kesemua projek',
    'Gantt chart for this project' => 'Carta Gantt untuk projek ini',
    'Project board' => 'Papan projek',
    'There is no start date or end date for this project.' => 'Tidak ada waktu mula atau waktu berakhir pada projek ini',
    'Projects Gantt chart' => 'projekkan carta Gantt',
    'Switch to the Gantt chart view' => 'Beralih ke tampilan Carta Gantt',
);

