<?php

return array(
    'Sort by position' => 'Rendezés pozíció szerint',
    'Sort by date' => 'Rendezés dátum szerint',
    'Add task' => 'Feladat hozzáadása',
    'There is no start date or due date for this task.' => 'Nincs kezdési dátum vagy határidő ehhez a feladathoz.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Egy feladat áthelyezése vagy átméretezése megváltoztatja a feladat kezdési dátumát és határidejét.',
    'There is no task in your project.' => 'Nincs feladat a projektjében.',
    'Gantt chart' => 'Gantt-diagram',
    'Gantt chart for all projects' => 'Gantt-diagram az összes projekthez',
    'Gantt chart for this project' => 'Gantt-diagram ehhez a projekthez',
    'Project board' => 'Projekt tábla',
    'There is no start date or end date for this project.' => 'Nincs kezdési dátum vagy befejezési dátum ehhez a projekthez.',
    'Projects Gantt chart' => 'A projektek Gantt-diagramja',
    'Switch to the Gantt chart view' => 'Váltás a Gantt-diagram nézetre',
);

