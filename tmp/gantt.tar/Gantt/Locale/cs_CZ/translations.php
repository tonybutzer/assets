<?php

return array(
    'Sort by position' => 'Třídit podle pozice',
    'Sort by date' => 'Třídit podle datumu',
    'Add task' => 'Přidat úkol',
    'There is no start date or due date for this task.' => 'Úkol nemá nastaven termín zahájení a dokončení.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Posunutím nebo prodloužením úkolu se změní počáteční a konečné datum úkolu. ',
    'There is no task in your project.' => 'Projekt neobsahuje žádné úkoly.',
    'Gantt chart' => 'Gantt graf',
    // 'Gantt chart for all projects' => '',
    // 'Gantt chart for this project' => '',
    // 'Project board' => '',
    // 'There is no start date or end date for this project.' => '',
    // 'Projects Gantt chart' => '',
    // 'Switch to the Gantt chart view' => '',
);

