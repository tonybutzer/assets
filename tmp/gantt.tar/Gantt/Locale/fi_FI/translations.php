<?php

return array(
    // 'Sort by position' => '',
    // 'Sort by date' => '',
    // 'Add task' => '',
    // 'There is no start date or due date for this task.' => '',
    // 'Moving or resizing a task will change the start and due date of the task.' => '',
    // 'There is no task in your project.' => '',
    // 'Gantt chart' => '',
    // 'Gantt chart for all projects' => '',
    // 'Gantt chart for this project' => '',
    // 'Project board' => '',
    // 'There is no start date or end date for this project.' => '',
    // 'Projects Gantt chart' => '',
    // 'Switch to the Gantt chart view' => '',
);

