<?php

return array(
    'Sort by position' => 'Pozisyona göre sırala',
    'Sort by date' => 'Tarihe göre sırala',
    'Add task' => 'Görev ekle',
    'There is no start date or due date for this task.' => 'Bu görev için başlangıç veya tamamlanması gereken tarih yok.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Bir görevin boyutunu değiştirmek, görevin başlangıç ve tamamlanması gereken tarihlerini değiştirir.',
    'There is no task in your project.' => 'Projenizde hiç görev yok.',
    'Gantt chart' => 'Gantt diyagramı',
    'Gantt chart for all projects' => 'Tüm projeler için Gantt diyagramı',
    'Gantt chart for this project' => 'Bu proje için Gantt diyagramı',
    'Project board' => 'Proje Panosu',
    'There is no start date or end date for this project.' => 'Bu proje için başlangıç veya bitiş tarihi yok.',
    'Projects Gantt chart' => 'Projeler Gantt diyagramı',
    'Switch to the Gantt chart view' => 'Gantt diyagramı görünümüne geç',
);

