<?php

return array(
    'Sort by position' => 'Urutkan berdasarkan posisi',
    'Sort by date' => 'Urutkan berdasarkan tanggal',
    'Add task' => 'Tambah tugas',
    'There is no start date or due date for this task.' => 'Tidak ada tanggal mulai dan batas waktu untuk tugas ini.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Memindahkan atau mengubah ukuran tugas anda akan mengubah tanggal mulai dan batas waktu dari tugas ini.',
    'There is no task in your project.' => 'Tidak ada tugas didalam proyek anda.',
    'Gantt chart' => 'Grafik Gantt',
    'Gantt chart for all projects' => 'Grafik Gantt untuk semua proyek',
    'Gantt chart for this project' => 'Grafik Gantt untuk proyek ini',
    'Project board' => 'Papan proyek',
    'There is no start date or end date for this project.' => 'Tidak ada waktu mulai atau waktu berakhir untuk proyek ini',
    'Projects Gantt chart' => 'Grafik Gantt proyek',
    'Switch to the Gantt chart view' => 'Beralih ke tampilan grafik Gantt',
);

