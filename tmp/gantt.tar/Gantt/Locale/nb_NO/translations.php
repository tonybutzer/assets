<?php

return array(
    // 'Sort by position' => '',
    'Sort by date' => 'Sorter etter dato',
    'Add task' => 'Legg til oppgave',
    'There is no start date or due date for this task.' => 'Det er ingen startdato eller frist for denne oppgaven',
    // 'Moving or resizing a task will change the start and due date of the task.' => '',
    'There is no task in your project.' => 'Det er ingen oppgaver i dette prosjektet',
    'Gantt chart' => 'Gantt skjema',
    // 'Gantt chart for all projects' => '',
    'Gantt chart for this project' => 'Gantt skjema for dette prosjektet',
    'Project board' => 'Prosjektsiden',
    // 'There is no start date or end date for this project.' => '',
    'Projects Gantt chart' => 'Gantt skjema for prosjekter',
    'Switch to the Gantt chart view' => 'Gantt skjema visning',
);

