<?php

return array(
    'Sort by position' => 'Ordenar por posição',
    'Sort by date' => 'Ordenar por data',
    'Add task' => 'Adicionar tarefa',
    'There is no start date or due date for this task.' => 'Não existe data de inicio ou data de vencimento para esta tarefa.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Mover ou redimensionar a tarefa irá alterar a data de inicio e vencimento da tarefa.',
    'There is no task in your project.' => 'Não existe tarefa no seu projeto.',
    'Gantt chart' => 'Gráfico de Gantt',
    'Gantt chart for all projects' => 'Gráfico de Gantt para todos os projetos',
    'Gantt chart for this project' => 'Gráfico de Gantt para este projeto',
    'Project board' => 'Quadro de projeto',
    'There is no start date or end date for this project.' => 'Não existe data de inicio ou fim para este projeto.',
    'Projects Gantt chart' => 'Gráfico de Gantt dos projetos',
    'Switch to the Gantt chart view' => 'Mudar para vista de gráfico de Gantt',
);

