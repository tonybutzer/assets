<?php

return array(
    'Sort by position' => 'Ordina per posizione',
    'Sort by date' => 'Ordina per data',
    'Add task' => 'Aggiungi task',
    'There is no start date or due date for this task.' => 'Nessuna data di inizio o di scadenza per questo task.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Spostando o ridimensionado un task ne modifca la data di inizio e di scadenza.',
    'There is no task in your project.' => 'Non ci sono task nel tuo progetto.',
    'Gantt chart' => 'Grafici Gantt',
    'Gantt chart for all projects' => 'Grafico Gantt per tutti i progetti',
    'Gantt chart for this project' => 'Grafico Gantt per questo progetto',
    'Project board' => 'Bacheca del progetto',
    'There is no start date or end date for this project.' => 'Non è prevista una data di inizio o fine per questo progetto.',
    'Projects Gantt chart' => 'Grafico Gantt dei progetti',
    'Switch to the Gantt chart view' => 'Passa alla vista Grafico Gantt',
);

