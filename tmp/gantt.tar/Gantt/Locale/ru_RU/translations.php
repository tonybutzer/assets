<?php

return array(
    'Sort by position' => 'Сортировать по позиции',
    'Sort by date' => 'Сортировать по дате',
    'Add task' => 'Добавить задачу',
    'There is no start date or due date for this task.' => 'Для этой задачи нет даты начала или завершения.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Изменение или перемещение задачи повлечет изменение даты начала и завершения задачи.',
    'There is no task in your project.' => 'В Вашем проекте задач нет.',
    'Gantt chart' => 'Диаграмма Ганта',
    'Gantt chart for all projects' => 'Диаграмма Ганта для всех проектов',
    'Gantt chart for this project' => 'Диаграмма Ганта для этого проекта',
    'Project board' => 'Доска проекта',
    'There is no start date or end date for this project.' => 'В проекте не указаны дата начала или завершения.',
    'Projects Gantt chart' => 'Диаграмма Ганта проектов',
    'Switch to the Gantt chart view' => 'Переключиться в режим диаграммы Ганта',
);

