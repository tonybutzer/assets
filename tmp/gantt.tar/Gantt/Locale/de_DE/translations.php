<?php

return array(
    'Sort by position' => 'Nach Position sortieren',
    'Sort by date' => 'Nach Datum sortieren',
    'Add task' => 'Aufgabe hinzufügen',
    'There is no start date or due date for this task.' => 'Diese Aufgabe hat kein Start oder Ablaufdatum.',
    'Moving or resizing a task will change the start and due date of the task.' => 'Aufgabe verschieben/ändern, ändert auch Start- und Ablaufdatum der Aufgabe.',
    'There is no task in your project.' => 'Es gibt keine Aufgabe in deinem Projekt',
    'Gantt chart' => 'Gantt Diagramm',
    'Gantt chart for all projects' => 'Gantt Diagramm für alle Projekte',
    'Gantt chart for this project' => 'Gantt Diagramm für dieses Projekt',
    'Project board' => 'Projekt Pinnwand',
    'There is no start date or end date for this project.' => 'Es gibt kein Startdatum oder Endedatum für dieses Projekt',
    'Projects Gantt chart' => 'Projekt Gantt Diagramm',
    'Switch to the Gantt chart view' => 'Zur Gantt-Diagramm Ansicht wechseln',
);

